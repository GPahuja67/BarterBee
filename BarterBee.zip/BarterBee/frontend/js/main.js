/* ============================
   1) Preloader (hinge close)
============================ */
const pre = document.getElementById('preloader');
window.addEventListener('load', () => {
  // Let the hinge + fade finish, then remove from flow
  setTimeout(() => pre.style.display = 'none', 1400);
});

/* ============================
   2) Mobile Drawer
============================ */
const menuBtn = document.querySelector('.menu');
const drawer = document.querySelector('.drawer');
if (menuBtn) {
  menuBtn.addEventListener('click', () => {
    const open = drawer.style.display === 'flex';
    drawer.style.display = open ? 'none' : 'flex';
    menuBtn.setAttribute('aria-expanded', (!open).toString());
  });
  // Close drawer on link click
  drawer.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    drawer.style.display = 'none';
    menuBtn.setAttribute('aria-expanded', 'false');
  }));
}

/* ============================
   3) Live Background Canvas
   Pastel aurora + floating blobs
============================ */
const c = document.getElementById('bg');
const ctx = c.getContext('2d', { alpha: false });

let W, H, dpr;
let blobs = [];
const PASTELS = [
  [228,216,248],  // #E4D8F8
  [201,228,222],  // #C9E4DE
  [246,230,203],  // #F6E6CB
  [244,215,215],  // #F4D7D7
  [220,231,255],  // #DCE7FF
];

function resize() {
  dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  W = c.width = Math.floor(innerWidth * dpr);
  H = c.height = Math.floor(innerHeight * dpr);
  c.style.width = innerWidth + 'px';
  c.style.height = innerHeight + 'px';
  initBlobs();
}
window.addEventListener('resize', resize);

function initBlobs(){
  const count = 7; // few, slow, classy
  blobs = [];
  for (let i=0; i<count; i++){
    const r = rand(120, 260) * dpr;
    const x = rand(r, W-r);
    const y = rand(r, H-r);
    const speed = rand(0.08, 0.22) * dpr;
    const hue = PASTELS[i % PASTELS.length];
    blobs.push({x,y,r,dx:randSign()*speed,dy:randSign()*speed,color:hue, t: Math.random()*1000});
  }
}

function rand(min,max){ return Math.random()*(max-min)+min; }
function randSign(){ return Math.random()<.5 ? -1 : 1; }

let mx = 0, my = 0; // cursor influence
window.addEventListener('mousemove', (e)=>{
  mx = (e.clientX / innerWidth) * W;
  my = (e.clientY / innerHeight) * H;
});

function drawAurora(t){
  // soft flowing bands using sine curves
  const rows = 4;
  for (let i = 0; i < rows; i++){
    const yBase = (H/(rows+1))*(i+1) + Math.sin((t*0.0006)+(i*1.3))*30*dpr;
    const amp = 60 * dpr;
    const grad = ctx.createLinearGradient(0, yBase-120*dpr, 0, yBase+120*dpr);
    const col = PASTELS[(i+2)%PASTELS.length];
    const c1 = `rgba(${col[0]},${col[1]},${col[2]},0.28)`;
    const c2 = `rgba(${col[0]},${col[1]},${col[2]},0.06)`;
    grad.addColorStop(0, c2);
    grad.addColorStop(0.5, c1);
    grad.addColorStop(1, c2);

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, yBase);
    for(let x=0;x<=W;x+= 40*dpr){
      const y = yBase + Math.sin((x*0.003) + t*0.0008 + i)*amp;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(W, H);
    ctx.lineTo(0, H);
    ctx.closePath();
    ctx.fill();
  }
}

function draw(t){
  // base background
  ctx.fillStyle = '#f7f7fb';
  ctx.fillRect(0,0,W,H);

  // aurora waves
  drawAurora(t);

  // blobs
  for (const b of blobs){
    // gentle cursor attraction
    const ax = (mx ? (mx - b.x) : 0) * 0.00003;
    const ay = (my ? (my - b.y) : 0) * 0.00003;
    b.dx += ax; b.dy += ay;

    b.x += b.dx;
    b.y += b.dy;

    // bounce softly
    if (b.x < b.r || b.x > W-b.r) b.dx *= -1;
    if (b.y < b.r || b.y > H-b.r) b.dy *= -1;

    // breathing radius
    const r = b.r * (1 + Math.sin(t*0.001 + b.t)*0.02);

    // radial gradient fill
    const g = ctx.createRadialGradient(b.x, b.y, r*0.1, b.x, b.y, r);
    const [r0,g0,b0] = b.color;
    g.addColorStop(0, `rgba(${r0},${g0},${b0},0.55)`);
    g.addColorStop(1, `rgba(${r0},${g0},${b0},0.04)`);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(b.x, b.y, r, 0, Math.PI*2);
    ctx.fill();
  }

  requestAnimationFrame(draw);
}
resize();
requestAnimationFrame(draw);

/* ============================
   4) Swipe Cards (Showcase)
============================ */
const deck = document.querySelector('.deck');
if (deck){
  const cards = Array.from(deck.querySelectorAll('.swap-card'));
  cards.forEach(card => enableSwipe(card));
}

function enableSwipe(card){
  let startX=0, startY=0, x=0, y=0, dragging=false;

  const onPointerDown = (e)=>{
    dragging=true; card.setPointerCapture(e.pointerId);
    startX = e.clientX; startY = e.clientY;
    card.style.transition = 'none';
    card.style.cursor = 'grabbing';
  };
  const onPointerMove = (e)=>{
    if(!dragging) return;
    x = e.clientX - startX; y = e.clientY - startY;
    const rot = x * 0.06;
    card.style.transform = `translate(${x}px, ${y}px) rotate(${rot}deg)`;
  };
  const onPointerUp = ()=>{
    if(!dragging) return; dragging=false;
    card.style.cursor = 'grab';
    const threshold = 140; // swipe feel
    if (Math.abs(x) > threshold){
      const dir = Math.sign(x);
      card.style.transition = 'transform .35s ease, opacity .35s ease';
      card.style.transform = `translate(${dir*innerWidth}px, ${y}px) rotate(${dir*18}deg)`;
      card.style.opacity = '0';
      setTimeout(()=> card.remove(), 360);
    } else {
      card.style.transition = 'transform .25s ease';
      card.style.transform = '';
    }
  };

  card.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointermove', onPointerMove);
  window.addEventListener('pointerup', onPointerUp);
}

/* ============================
   5) Gentle scroll to anchors
============================ */
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click', (e)=>{
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if(!el) return;
    e.preventDefault();
    const y = el.getBoundingClientRect().top + window.scrollY - 88;
    window.scrollTo({ top:y, behavior:'smooth' });
  });
});
